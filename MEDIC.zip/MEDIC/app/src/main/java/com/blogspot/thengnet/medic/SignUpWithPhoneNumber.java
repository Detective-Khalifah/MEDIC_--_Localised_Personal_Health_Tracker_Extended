package com.blogspot.thengnet.medic;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpWithPhoneNumber extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_with_phone_number);
    }
}